def null_positions(street):
    """
    gets indexes of nulls in array
    """
    nulls =[]
    for i in range(len(street)):
        if street[i] == 0:
            nulls.append(i)
    # print("Nulls", nulls)
    return nulls

def dist_to_null(street):
    nulls = null_positions(street)
    lst_of_dist = []
    first = nulls[0]
    last = nulls[-1]
    # fill up to first zero
    for y in range(first):
        dist = abs(first - y)
        lst_of_dist.append(dist)
    # fill the middle
    for j in range(0,len(nulls)-1):
        start = nulls[j]
        end = nulls[j+1]
        for q in range(start,end):
            dist = min(abs(start - q),abs(end - q))
            lst_of_dist.append(dist)
    # fill from last zero till end of array
    for d in range(0,len(street)-last):
        if len(street) - last == 1:
            lst_of_dist.append(0)
        else:
            lst_of_dist.append(d)
    # print("distances", lst_of_dist)
    return lst_of_dist

n = input()
s = input()
street = list(map(int, s.split()))
print(*dist_to_null(street))


# assert(dist_to_null([44,44,44,0,22,22]) == [3,2,1,0,1,2])
# assert(dist_to_null([0,1,4,9,0]) == [0,1,2,1,0])
# assert(dist_to_null([0,7,9,4,8,20]) == [0,1,2,3,4,5])
# assert(dist_to_null([0]) == [0])
# assert(dist_to_null([0, 1]) == [0,1])
# assert(dist_to_null([1,2,3,0]) == [3,2,1,0])

